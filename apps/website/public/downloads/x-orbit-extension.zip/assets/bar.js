(function(){"use strict";(()=>{const f="orbit-bar-host",x=document.getElementById(f);if(x){x.remove();return}const s=document.createElement("div");s.id=f,s.style.cssText="all:initial;position:fixed;inset:0;z-index:2147483647";const v=s.attachShadow({mode:"closed"});v.innerHTML=`
  <style>
    :host{all:initial}
    *{box-sizing:border-box}
    .scrim{position:fixed;inset:0;background:rgba(0,0,0,.5);display:flex;justify-content:center;align-items:flex-end;padding:0 20px 24px;animation:f .12s ease-out;font:14px/1.4 Inter,system-ui,-apple-system,"Segoe UI",sans-serif}
    @keyframes f{from{opacity:0}} @keyframes r{from{opacity:0;transform:translateY(8px) scale(.985)}}
    .panel{width:min(680px,100%);display:flex;flex-direction:column-reverse;background:var(--orbit-bar,#111);color:var(--orbit-text,#f5f5f2);border:1px solid var(--orbit-border-strong,rgba(255,255,255,.22));border-radius:16px;overflow:hidden;box-shadow:0 30px 80px rgba(0,0,0,.5);animation:r .16s cubic-bezier(.2,0,0,1)}
    .row{display:flex;align-items:center;gap:12px;height:52px;padding:0 18px;border-top:1px solid var(--orbit-border,rgba(255,255,255,.12));color:var(--orbit-text-2,#a0a0a0)}
    input{flex:1;min-width:0;background:none;border:0;outline:0;color:var(--orbit-text,#f5f5f2);font:inherit;font-size:15px}
    kbd{font:10px ui-monospace,Menlo,monospace;color:var(--orbit-muted,#686868);border:1px solid var(--orbit-border,rgba(255,255,255,.12));border-radius:4px;padding:1px 5px}
    ul{list-style:none;margin:0;padding:6px 6px 0;max-height:52vh;overflow:auto}
    ul:empty{display:none}
    li{display:flex;align-items:center;gap:12px;height:38px;padding:0 12px;border-radius:8px;cursor:default}
    li[aria-selected=true]{background:var(--orbit-tab-active,#1a1a1a)}
    li img,li .ico{width:16px;height:16px;flex:none;border-radius:3px}
    li .ico{display:grid;place-items:center;color:var(--orbit-muted,#686868);font-size:12px}
    .t{flex:none;max-width:55%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .s{flex:1;min-width:0;text-align:right;color:var(--orbit-muted,#686868);font:11px ui-monospace,Menlo,monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    @media (prefers-reduced-motion:reduce){*{animation:none!important}}
  </style>
  <div class="scrim"><div class="panel" role="dialog" aria-label="Orbit Bar">
    <div class="row"><span aria-hidden="true">⌕</span><input spellcheck="false" autocomplete="off" placeholder="Search, enter address, @tabs, @history, /settings" aria-label="Search or enter address"><kbd>esc</kbd></div>
    <ul role="listbox"></ul>
  </div></div>`;const c=e=>v.querySelector(e),r=c("input"),k=c("ul"),p=c(".scrim");let l=[],b="",n=0,g=0;const u=()=>{s.remove(),document.removeEventListener("keydown",y,!0)},y=e=>{e.key==="Escape"&&(e.stopPropagation(),u())},d=()=>{k.replaceChildren(...l.map((e,o)=>{const t=document.createElement("li");if(t.setAttribute("role","option"),t.setAttribute("aria-selected",String(o===n)),e.favicon){const a=document.createElement("img");a.src=e.favicon,a.alt="",t.append(a)}else{const a=document.createElement("span");a.className="ico",a.textContent=e.kind==="command"?"›":e.kind==="calc"?"=":"⌕",t.append(a)}const i=document.createElement("span");i.className="t",i.textContent=e.title;const m=document.createElement("span");return m.className="s",m.textContent=e.sub??"",t.append(i,m),t.onmousemove=()=>{n!==o&&(n=o,d())},t.onclick=()=>h(e,!1),t}))},h=async(e,o)=>{const t=r.value;if(u(),e?.run.type==="copy"){try{await navigator.clipboard.writeText(String(e.run.payload.text))}catch{}return}const i=e?{...e.run,payload:e.run.type==="navigate"?{...e.run.payload,newTab:o}:e.run.payload}:t.trim()?{type:"navigate",payload:{input:t,newTab:o}}:null;i&&chrome.runtime.sendMessage({type:"run",run:i})},w=async()=>{const e=++g,o=r.value,t=await chrome.runtime.sendMessage({type:"suggest",text:r.value});e===g&&t&&(l=t,b=o,n=0,d())};r.addEventListener("input",w),r.addEventListener("keydown",e=>{e.stopPropagation(),e.key==="ArrowDown"?(e.preventDefault(),n=Math.min(n+1,l.length-1),d()):e.key==="ArrowUp"?(e.preventDefault(),n=Math.max(n-1,0),d()):e.key==="Enter"&&(e.preventDefault(),h(b===r.value?l[n]:void 0,e.metaKey||e.ctrlKey))});for(const e of["keyup","keypress"])r.addEventListener(e,o=>o.stopPropagation());p.addEventListener("mousedown",e=>{e.target===p&&u()}),document.addEventListener("keydown",y,!0),document.documentElement.append(s),chrome.runtime.sendMessage({type:"init"}).then(e=>{if(e)for(const[o,t]of Object.entries(e.vars))o.startsWith("--")&&p.style.setProperty(o,t)}),r.focus(),w()})()})();
